import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddmoneyComponent } from './addmoney/addmoney.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { DisplayAccountComponent } from './display-account/display-account.component';
import { SearchAccountComponent } from './search-account/search-account.component';
import { TransferMoneyComponent } from './transfer-money/transfer-money.component';
import { HomeComponent } from './home/home.component';
import {FormsModule} from '@angular/forms';
import { AccountpipePipe } from './accountpipe.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AddmoneyComponent,
    CreateaccountComponent,
    DisplayAccountComponent,
    SearchAccountComponent,
    TransferMoneyComponent,
    HomeComponent,
    AccountpipePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
