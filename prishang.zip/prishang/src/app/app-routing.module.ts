import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {  HomeComponent } from './home/home.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { SearchAccountComponent} from './search-account/search-account.component';
import { AddmoneyComponent } from './addmoney/addmoney.component';
import { TransferMoneyComponent } from './transfer-money/transfer-money.component';
import { DisplayAccountComponent } from './display-account/display-account.component';



const routes: Routes = [
  {
    path: '',
    component:  HomeComponent
  },
  {
    path: 'create',
    component:  CreateaccountComponent
  },
  {
    path: 'search',
    component: SearchAccountComponent
  },
  {
    path: 'addmoney',
    component: AddmoneyComponent
  },
  {
    path: 'transfer',
    component: TransferMoneyComponent
  },
  {
    path: 'showall',
    component:  DisplayAccountComponent 
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
