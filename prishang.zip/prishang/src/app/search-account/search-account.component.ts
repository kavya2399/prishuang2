import { Component, OnInit } from '@angular/core';
import accounts from '../../accounts/acc.json';

@Component({
  selector: 'app-search-account',
  templateUrl: './search-account.component.html',
  styleUrls: ['./search-account.component.css']
})
export class SearchAccountComponent implements OnInit {
  array=accounts
  flag=false
  constructor() { }

  ngOnInit() {
  }
  setFlag()
  {
    this.flag=true
  }

}
