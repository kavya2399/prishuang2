import { AccountpipePipe } from './accountpipe.pipe';

describe('AccountpipePipe', () => {
  it('create an instance', () => {
    const pipe = new AccountpipePipe();
    expect(pipe).toBeTruthy();
  });
});
