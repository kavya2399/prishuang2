import { Component, OnInit } from '@angular/core';
import accounts from '../../accounts/acc.json'

@Component({
  selector: 'app-display-account',
  templateUrl: './display-account.component.html',
  styleUrls: ['./display-account.component.css']
})
export class DisplayAccountComponent implements OnInit {
array=accounts
  constructor() { }

  ngOnInit() {
  }

}
